var categories = [{
  text: "封面"
}, {
  text: "关于北京字节跳动"
}];